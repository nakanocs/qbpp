/// @file license_check.cpp
/// @brief License check sample program.
/// @author Koji Nakano
/// @version 2025.10.04

#include "qbpp.hpp"
int main() {
  auto license = qbpp::license_info();
  if (license.license_status_ == qbpp::LicenseStatus::StandardLicense ||
      license.license_status_ == qbpp::LicenseStatus::ProfessionalLicense) {
    std::cout << qbpp::license_info() << std::endl;
  }
  return 0;
}