# README Version: 2025.10.04
* **Maintainer:** Koji Nakano

# QUBO++
* A C++ library for constructing polynomials of binary variables to solve combinatorial optimization problems  
* Currently built for **x86_64 Linux systems**  
* Bundled with two CPU solvers: Easy Solver (heuristic) and Exhaustive Solver (complete search)  
* Bundled with a GPU solver: ABS3  
* Supports High-order Unconstrained Binary Optimization (HUBO) up to degree 8  
* Multithreading acceleration is applied using oneTBB wherever possible  
* Includes APIs for calling the Gurobi Optimizer to solve Quadratic Unconstrained Binary Optimization (QUBO) problems  
* Author: Koji Nakano  
* Copyright: © 2025 Koji Nakano. All rights reserved.

## Build Environment
The following environment was used to build QUBO++.  
To ensure compatibility, please use the same or newer versions of the listed components.
- **Operating System**: Ubuntu 20.04.6 LTS 
- **glibc**: 2.31  
- **C++ Standard**: C++17  
- **Compiler**: g++ 9.4.0  
- **Boost**: 1.81.0
- **CUDA**: 12.8

## oneTBB / TBB dependency
QUBO++ does not bundle TBB. We include TBB headers in public APIs, but the
library itself does not require linking against TBB for the default use cases.
- **Build & run verified on**: Ubuntu 20.04 (classic TBB 2020.1), 22.04 / 24.04 (oneTBB 2021+).

## Directory Structure and Key Files

- `include/` — Header files  
  - `qbpp.hpp`: Main QUBO++ BQ Edition toolkit 
  - `qbpp_abs3_solver.hpp`: ABS3 GPU Solver 
  - `qbpp_defs.hpp`: Common definitions and macros  
  - `qbpp_easy_solver.hpp`: Easy Solver implementation  
  - `qbpp_exhaustive_solver.hpp`: Exhaustive Solver implementation  
  - `qbpp_grb.hpp`: Gurobi Optimizer interface
  - `qbpp_misc.hpp`: Miscelleneous library

- `lib/` — QUBO++ shared libraries  
  - `libqbpp.so`: Shared library for the QUBO++ core  
  - `libqbpp_abs3c32.so`: Shared library for the ABS3 GPU solver with 32-bit term coefficients  
  - `libqbpp_abs3c64.so`: Shared library for the ABS3 GPU solver with 64-bit term coefficients

- `samples/` — Sample programs
  - `license_check.cpp`: QUBO++ license check program 
  - `factorization.cpp`: Integer factorization
  - `graph_color.cpp`: Graph coloring
  - `tsp.cpp`: Solving Traveling Salesman Problem using Easy Solver
  - `qbpp_tsp.hpp: Creating QUBO model for the TSP
  - `integer_poly.cpp`: Integer polynomial optimization  
  - `labs.cpp`: Low Autocorrelation Binary Sequences problem  
  - `nqueen_easy.cpp`: Solving N-Queens problem using Easy Solver 
  - `qbpp_nqueen.hpp`: Generates QUBO expression for the N-Queens problem
  - `shift_scheduling`: Shift scheduling problem
  - `factorization_abs3.cpp`: Integer factorization using ABS3
  - `labs_abs3.cpp`: Low Autocorrelation Binary Sequences problem using ABS3 GPU solver
  - `ilp_grb`: Integer Linear Programming example using Gurobi Optimizer

- **Supported GPU architectures**
  - **sm_80** : NVIDIA A100  (Ampere) 
  - **sm_86** : NVIDIA RTX A6000, GeForce RTX 3090/3080/3070 (Ampere) 
  - **sm_89** : NVIDIA RTX 6000 Ada, GeForce RTX 4090/4080/4070 (Ada) 
  - **sm_90** : NVIDIA H100 / H200 / GH200 (Hopper) 
  - **sm_100** : NVIDIA B200 / GB200 (Blackwell, data center) 
  - **sm_120** : GeForce RTX 5090/5080/5070(Ti)/5060(Ti)/5050、RTX PRO 6000/5000/4500/4000/2000 Blackwell (workstation)  
  - **Note on verification** : Only a subset of the architectures above has been verified on real hardware.  

- **Numeric types**
  - 32-bit and 64-bit term coefficients
  - 64-bit energy values

- **Performance note**
  - Arithmetic overflow checks are omitted to maximize performance.

# QUBO++ Licensing

## License Types

- **Anonymous Trial**  
  - No license key required  
  - Valid for 7 days  
  - Maximum variable count: **1,000 (CPU) / 1,000 (GPU)**  

- **Registered Trial**  
  - Requires a free license key  
  - Valid for 30 days  
  - Maximum variable count: **10,000 (CPU) / 10,000 (GPU)**  

- **Standard License**  
  - Requires a paid license key  
  - Valid for the duration of the license agreement  
  - Maximum variable count: **2,147,483,647 ($2^{31} - 1$) (CPU) / 1,000 (GPU)**  
  - *Practically, the maximum variable count may be limited by available physical memory.*  

- **Professional License**  
  - Requires a paid license key  
  - Valid for the duration of the license agreement  
  - Maximum variable count: **2,147,483,647 ($2^{31} - 1$) (CPU) / 2,147,483,647 ($2^{31} - 1$) (GPU)**  
  - *Practically, the maximum variable count may be limited by available physical memory.*  

- **Fallback (No license / Expired license)**   
  - Maximum variable count: **100 (CPU) / 100 (GPU)**


## How to Set the License

For **Registered Trial**, **Standard License**, and **Professional License**, set the license key using either of the following methods:

- **Via Code**:
  ```cpp
  qbpp::license_key("XXXXXX-XXXXXX-XXXXXX-XXXXXX-XXXXXX-XXXXXX");
  ```
- **Via Environment Variable**:
  ```bash
  export QBPP_LICENSE_KEY=XXXXXX-XXXXXX-XXXXXX-XXXXXX-XXXXXX-XXXXXX
  ```
  
# Terms and Conditions

By using QUBO++, you agree to the following terms and conditions:

1. **License Scope**  
   QUBO++ is provided under a time-limited license, depending on the license type (Anonymous Trial, Registered Trial, Standard or Professional License).

2. **Restrictions on Trial Licenses**  
   The Anonymous Trial and Registered Trial licenses are provided strictly for evaluation purposes only.  

3. **Standard/Professional Licenses and Payment Requirement**  
   Standard/Professional Licenses require the purchase of a paid license key. These licenses grant full access to QUBO++ for commercial and research use, subject to the terms of the license agreement.

4. **Redistribution**  
   Redistribution of QUBO++ (in whole or in part, including headers and binaries) is prohibited without prior written permission from the copyright holder.

5. **Reverse Engineering**  
   You may not reverse engineer, decompile, or disassemble any part of the software.

6. **Disclaimer**  
   QUBO++ is provided "as is," without any warranties, express or implied. The authors shall not be held liable for any damages resulting from the use of this software.

7. **Ownership**  
   All intellectual property rights related to QUBO++ remain the property of the original author or copyright holder.

8. **Termination**  
   This license will automatically terminate if you fail to comply with these terms. Upon termination, you must cease all use of the software and destroy all copies.

# Third-Party Libraries

- **Gurobi Optimizer**  
  - QUBO++ supporting APIs for integration with the Gurobi Optimizer.  
  - To use these APIs, you must obtain a valid license for the Gurobi Optimizer from Gurobi Optimization, LLC.  
  - The Gurobi Optimizer is not included with QUBO++, and its use is subject to the terms and conditions of its own license agreement.

- **oneTBB (oneAPI Threading Building Blocks)**  
  - Licensed under the Apache License 2.0.  
  - Copyright © Intel Corporation.  
  - See <https://www.apache.org/licenses/LICENSE-2.0> for details.  
  - *Note:* If you redistribute binaries that include oneTBB, include the Apache 2.0 license text and any required NOTICE.

- **Boost C++ Libraries**  
  - Licensed under the Boost Software License, Version 1.0.  
  - See <https://www.boost.org/LICENSE_1_0.txt> for details.

- **xxHash**  
  - Licensed under the BSD 2-Clause License.  
  - Copyright © Yann Collet.  
  - See <https://opensource.org/license/bsd-2-clause/> for details.




If you have any questions regarding licensing or wish to obtain a license key, please contact the distributor or the developer.

