/// @file qbpp_exhaustive_solver.hpp
/// @author Koji Nakano
/// @brief Exhaustive HUBO Solver for solving HUBO problems.
/// @details The ExhaustiveSolver class provides a straightforward HUBO solver
/// that evaluates all possible solutions. This solver is primarily intended
/// for testing the correctness of HUBO expressions.
/// For more details on the algorithm, please refer to the following paper:
/// Masaki Tao et al., "A Work-Time Optimal Parallel Exhaustive Search
/// Algorithm for the QUBO and the Ising Model, with GPU Implementation," IPDPS
/// Workshops 2020: 557-566. https://doi.org/10.1109/IPDPSW50202.2020.00098
/// @version 2025.06.12

#pragma once
#include <tbb/blocked_range.h>
#include <tbb/parallel_for.h>
#include <boost/circular_buffer.hpp>
#include <random>
#include <set>
#include "qbpp.hpp"
namespace qbpp {
namespace exhaustive_solver {
class SolDelta;
class Sol;
class SearchAlgorithm;
class ExhaustiveSolver;
class Sol : public qbpp::Sol {
  bool is_all_solutions_ = false;
  bool is_optimal_solutions_ = false;
  std::vector<qbpp::Sol> all_solutions_;
 public:
  explicit Sol(const HuboModel &hubo_model) : qbpp::Sol(hubo_model){};
  Sol(const Sol &) = default;
  Sol(Sol &&) = default;
  Sol &operator=(const Sol &) = default;
  Sol &operator=(Sol &&) = default;
  std::vector<qbpp::Sol> &all_solutions() { return all_solutions_; }
  qbpp::Sol sol() const { return all_solutions_.front(); }
  void all_solution_mode() {
    is_optimal_solutions_ = false;
    is_all_solutions_ = true;
  }
  void optimal_solution_mode() {
    is_optimal_solutions_ = true;
    is_all_solutions_ = false;
  }
  void all_solutions(std::vector<qbpp::Sol> &&all_solutions) {
    all_solutions_ = all_solutions;
    qbpp::Sol::operator=(all_solutions_.front());
  }
  std::string str() const {
    if (is_all_solutions_ || is_optimal_solutions_) {
      std::ostringstream oss;
      uint32_t count = 0;
      for (const auto &sol : all_solutions_) {
        oss << count++ << ":" << sol;
        if (count < all_solutions_.size()) oss << std::endl;
      }
      return oss.str();
    }
    return qbpp::str(static_cast<qbpp::Sol>(*this));
  }
  std::vector<qbpp::Sol>::const_iterator begin() const {
    return all_solutions_.begin();
  }
  std::vector<qbpp::Sol>::const_iterator end() const {
    return all_solutions_.end();
  }
  size_t size() const { return all_solutions_.size(); }
  const qbpp::Sol &operator[](size_t i) const { return all_solutions_[i]; }
  qbpp::Sol &operator[](size_t i) { return all_solutions_[i]; }
};
inline std::ostream &operator<<(std::ostream &os, const Sol &sol) {
  os << sol.str();
  return os;
}
class ExhaustiveSolver {
 protected:
  const HuboModel hubo_model_;
  bool enable_default_callback_ = false;
 public:
  ExhaustiveSolver(const HuboModel &hubo_model) : hubo_model_(hubo_model) {}
  mutable std::mutex callback_mutex_;
  virtual ~ExhaustiveSolver() = default;
  virtual void callback(const SolHolder &sol_holder) const {
    static std::optional<energy_t> prev_energy = std::nullopt;
    std::lock_guard<std::mutex> lock(callback_mutex_);
    if (enable_default_callback_) {
      if (!prev_energy.has_value() ||
          sol_holder.energy() < prev_energy.value()) {
        prev_energy = sol_holder.energy();
        std::cout << "TTS = " << std::fixed << std::setprecision(3)
                  << std::setfill('0') << sol_holder.tts()
                  << "s Energy = " << sol_holder.energy() << std::endl;
      }
    }
  }
  vindex_t var_count() const { return hubo_model_.var_count(); }
  qbpp::Sol search();
  Sol search_optimal_solutions();
  Sol search_all_solutions();
  void enable_default_callback(bool enable = true) {
    enable_default_callback_ = enable;
  }
  const HuboModel &hubo_model() const { return hubo_model_; }
};
class SearchAlgorithm {
  const ExhaustiveSolver &exhaustive_solver_;
  const HuboModel &hubo_model_;
  const std::vector<vindex_t> var_order_;
  qbpp::SolHolder sol_holder_;
  bool is_all_solutions_ = false;
  bool is_optimal_solutions_ = false;
  std::vector<qbpp::Sol> all_solutions_;
  mutable std::mutex all_solutions_mutex_;
  std::vector<SolDelta> sol_deltas;
  std::vector<vindex_t> init_var_order(const HuboModel &hubo_model) {
    std::vector<std::pair<vindex_t, vindex_t>> degree_var;
    degree_var.resize(hubo_model.var_count());
    for (vindex_t i = 0; i < hubo_model.var_count(); ++i) {
      degree_var[i] = std::make_pair(hubo_model.degree(i), i);
    }
    std::sort(degree_var.begin(), degree_var.end(), std::greater<>());
    std::vector<vindex_t> var_order;
    var_order.resize(hubo_model.var_count());
    for (vindex_t i = 0; i < hubo_model.var_count(); ++i) {
      var_order[i] = degree_var[i].second;
    }
    return var_order;
  }
 public:
  explicit SearchAlgorithm(const ExhaustiveSolver &exhaustive_solver)
      : exhaustive_solver_(exhaustive_solver),
        hubo_model_(exhaustive_solver_.hubo_model()),
        var_order_(init_var_order(hubo_model_)),
        sol_holder_(hubo_model_) {}
  const HuboModel &hubo_model() const { return hubo_model_; }
  const std::vector<vindex_t> &var_order() const { return var_order_; }
  vindex_t var_count() const { return hubo_model_.var_count(); }
  std::vector<qbpp::Sol> &all_solutions() { return all_solutions_; }
  qbpp::SolHolder &sol_holder() { return sol_holder_; }
  void register_new_sol(const qbpp::Sol &sol) {
    if (!is_all_solutions_ && sol_holder_.energy() < sol.energy()) return;
    std::lock_guard<std::mutex> lock(all_solutions_mutex_);
    if (is_all_solutions_) {
      all_solutions_.push_back(sol);
    } else if (is_optimal_solutions_) {
      if (sol_holder_.energy() == sol.energy()) {
        all_solutions_.push_back(sol);
      } else if (sol_holder_.energy() > sol.energy()) {
        all_solutions_.clear();
        all_solutions_.push_back(sol);
      }
    }
    if (sol_holder_.set_if_better(sol)) {
      exhaustive_solver_.callback(sol_holder_);
    }
  }
  void search();
  void search_optimal_solutions();
  void search_all_solutions();
  void gen_sol_deltas(SolDelta &sol_delta, vindex_t index);
};
class SolDelta : public Sol {
 protected:
  const HuboModel &hubo_model_;
  SearchAlgorithm &search_algorithm_;
  const std::vector<vindex_t> &var_order_ = search_algorithm_.var_order();
  std::vector<energy_t> delta_;
 public:
  explicit SolDelta(SearchAlgorithm &search_algorithm)
      : Sol(search_algorithm.hubo_model()),
        hubo_model_(search_algorithm.hubo_model()),
        search_algorithm_(search_algorithm) {
    delta_.resize(var_count());
    for (vindex_t i = 0; i < var_count(); ++i) {
      delta_[i] = search_algorithm.hubo_model().term1(i);
    }
  }
  void flip(vindex_t flip_index) override {
    vindex_t index = var_order_[flip_index];
    if (index >= var_count()) {
      throw std::out_of_range(
          THROW_MESSAGE("Sol: index (", index, ") out of range"));
    }
    energy_ = energy() + delta_[index];
    int32_t flip_bit_sign = 1 - 2 * get(index);
    std::vector<energy_t> delta_delta(var_count(), 0);
    auto t2 = hubo_model_.term2(index);
    for (size_t i = 0; i < t2.size(); ++i) {
      vindex_t j = t2.indices(i)[0];
      coeff_t coeff = t2.coeff(i);
      delta_delta[j] += coeff * flip_bit_sign * (1 - 2 * get(j));
    }
    auto t3 = hubo_model_.term3(index);
    for (size_t i = 0; i < t3.size(); ++i) {
      vindex_t j = t3.indices(i)[0];
      vindex_t k = t3.indices(i)[1];
      coeff_t coeff = t3.coeff(i);
      if (get(j) != 0) {
        delta_delta[k] += coeff * flip_bit_sign * (1 - 2 * get(k));
      }
      if (get(k) != 0) {
        delta_delta[j] += coeff * flip_bit_sign * (1 - 2 * get(j));
      }
    }
    auto t4 = hubo_model_.term4(index);
    for (size_t i = 0; i < t4.size(); ++i) {
      vindex_t i0 = t4.indices(i)[0];
      vindex_t i1 = t4.indices(i)[1];
      vindex_t i2 = t4.indices(i)[2];
      int8_t val0 = get(i0);
      int8_t val1 = get(i1);
      int8_t val2 = get(i2);
      int32_t sum = val0 + val1 + val2;
      energy_t factor = t4.coeff(i) * flip_bit_sign;
      if (sum <= 1) continue;
      if (sum == 3) {
        delta_delta[i0] -= factor;
        delta_delta[i1] -= factor;
        delta_delta[i2] -= factor;
        continue;
      }
      if (val0 == 0) {
        delta_delta[i0] += factor;
      } else if (val1 == 0) {
        delta_delta[i1] += factor;
      } else {
        delta_delta[i2] += factor;
      }
    }
    auto t5 = hubo_model_.term5(index);
    for (size_t i = 0; i < t5.size(); ++i) {
      vindex_t i0 = t5.indices(i)[0];
      vindex_t i1 = t5.indices(i)[1];
      vindex_t i2 = t5.indices(i)[2];
      vindex_t i3 = t5.indices(i)[3];
      int8_t val0 = get(i0);
      int8_t val1 = get(i1);
      int8_t val2 = get(i2);
      int8_t val3 = get(i3);
      int32_t sum = val0 + val1 + val2 + val3;
      energy_t factor = t5.coeff(i) * flip_bit_sign;
      if (sum <= 2) continue;
      if (sum == 4) {
        delta_delta[i0] -= factor;
        delta_delta[i1] -= factor;
        delta_delta[i2] -= factor;
        delta_delta[i3] -= factor;
        continue;
      }
      if (val0 == 0) {
        delta_delta[i0] += factor;
      } else if (val1 == 0) {
        delta_delta[i1] += factor;
      } else if (val2 == 0) {
        delta_delta[i2] += factor;
      } else {
        delta_delta[i3] += factor;
      }
    }
    auto t6 = hubo_model_.term6(index);
    for (size_t i = 0; i < t6.size(); ++i) {
      vindex_t i0 = t6.indices(i)[0];
      vindex_t i1 = t6.indices(i)[1];
      vindex_t i2 = t6.indices(i)[2];
      vindex_t i3 = t6.indices(i)[3];
      vindex_t i4 = t6.indices(i)[4];
      int8_t val0 = get(i0);
      int8_t val1 = get(i1);
      int8_t val2 = get(i2);
      int8_t val3 = get(i3);
      int8_t val4 = get(i4);
      int32_t sum = val0 + val1 + val2 + val3 + val4;
      energy_t factor = t6.coeff(i) * flip_bit_sign;
      if (sum <= 3) continue;
      if (sum == 5) {
        delta_delta[i0] -= factor;
        delta_delta[i1] -= factor;
        delta_delta[i2] -= factor;
        delta_delta[i3] -= factor;
        delta_delta[i4] -= factor;
        continue;
      }
      if (val0 == 0)
        delta_delta[i0] += factor;
      else if (val1 == 0)
        delta_delta[i1] += factor;
      else if (val2 == 0)
        delta_delta[i2] += factor;
      else if (val3 == 0)
        delta_delta[i3] += factor;
      else
        delta_delta[i4] += factor;
    }
    auto t7 = hubo_model_.term7(index);
    for (size_t i = 0; i < t7.size(); ++i) {
      vindex_t i0 = t7.indices(i)[0];
      vindex_t i1 = t7.indices(i)[1];
      vindex_t i2 = t7.indices(i)[2];
      vindex_t i3 = t7.indices(i)[3];
      vindex_t i4 = t7.indices(i)[4];
      vindex_t i5 = t7.indices(i)[5];
      int8_t val0 = get(i0);
      int8_t val1 = get(i1);
      int8_t val2 = get(i2);
      int8_t val3 = get(i3);
      int8_t val4 = get(i4);
      int8_t val5 = get(i5);
      int32_t sum = val0 + val1 + val2 + val3 + val4 + val5;
      energy_t factor = t7.coeff(i) * flip_bit_sign;
      if (sum <= 4) continue;
      if (sum == 6) {
        delta_delta[i0] -= factor;
        delta_delta[i1] -= factor;
        delta_delta[i2] -= factor;
        delta_delta[i3] -= factor;
        delta_delta[i4] -= factor;
        delta_delta[i5] -= factor;
        continue;
      }
      if (val0 == 0)
        delta_delta[i0] += factor;
      else if (val1 == 0)
        delta_delta[i1] += factor;
      else if (val2 == 0)
        delta_delta[i2] += factor;
      else if (val3 == 0)
        delta_delta[i3] += factor;
      else if (val4 == 0)
        delta_delta[i4] += factor;
      else
        delta_delta[i5] += factor;
    }
    auto t8 = hubo_model_.term8(index);
    for (size_t i = 0; i < t8.size(); ++i) {
      vindex_t i0 = t8.indices(i)[0];
      vindex_t i1 = t8.indices(i)[1];
      vindex_t i2 = t8.indices(i)[2];
      vindex_t i3 = t8.indices(i)[3];
      vindex_t i4 = t8.indices(i)[4];
      vindex_t i5 = t8.indices(i)[5];
      vindex_t i6 = t8.indices(i)[6];
      int8_t val0 = get(i0);
      int8_t val1 = get(i1);
      int8_t val2 = get(i2);
      int8_t val3 = get(i3);
      int8_t val4 = get(i4);
      int8_t val5 = get(i5);
      int8_t val6 = get(i6);
      int32_t sum = val0 + val1 + val2 + val3 + val4 + val5 + val6;
      energy_t factor = t8.coeff(i) * flip_bit_sign;
      if (sum <= 5) continue;
      if (sum == 7) {
        delta_delta[i0] -= factor;
        delta_delta[i1] -= factor;
        delta_delta[i2] -= factor;
        delta_delta[i3] -= factor;
        delta_delta[i4] -= factor;
        delta_delta[i5] -= factor;
        delta_delta[i6] -= factor;
        continue;
      }
      if (val0 == 0)
        delta_delta[i0] += factor;
      else if (val1 == 0)
        delta_delta[i1] += factor;
      else if (val2 == 0)
        delta_delta[i2] += factor;
      else if (val3 == 0)
        delta_delta[i3] += factor;
      else if (val4 == 0)
        delta_delta[i4] += factor;
      else if (val5 == 0)
        delta_delta[i5] += factor;
      else
        delta_delta[i6] += factor;
    }
    for (vindex_t i = 0; i < var_count(); ++i) {
      if (delta_delta[i] == 0) continue;
      if (i == index)
        throw std::runtime_error(
            THROW_MESSAGE("Unexpected error. delta_delta[i] != 0"));
      delta_[i] += delta_delta[i];
    }
    delta_[index] = -delta_[index];
    if (!energy_.has_value()) {
      throw std::out_of_range(THROW_MESSAGE("energy_ is not set."));
    }
    bit_vector_.flip(index);
  }
  void search(vindex_t index) {
    if (index >= 1) search(index - 1);
    flip(index);
    search_algorithm_.register_new_sol(*this);
    if (index >= 1) search(index - 1);
  }
  void search() {
    search_algorithm_.register_new_sol(*this);
    search(var_count() - 1);
  }
};
inline qbpp::Sol ExhaustiveSolver::search() {
  SearchAlgorithm search_algorithm(*this);
  search_algorithm.search();
  return search_algorithm.sol_holder().sol();
}
inline Sol ExhaustiveSolver::search_optimal_solutions() {
  SearchAlgorithm search_algorithm(*this);
  search_algorithm.search_optimal_solutions();
  Sol sol(hubo_model_);
  sol.optimal_solution_mode();
  sol.all_solutions(std::move(search_algorithm.all_solutions()));
  return sol;
}
inline Sol ExhaustiveSolver::search_all_solutions() {
  SearchAlgorithm search_algorithm(*this);
  search_algorithm.search_all_solutions();
  Sol sol(hubo_model_);
  sol.all_solution_mode();
  sol.all_solutions(std::move(search_algorithm.all_solutions()));
  return sol;
}
inline void SearchAlgorithm::gen_sol_deltas(SolDelta &sol_delta,
                                            vindex_t index) {
  if (var_count() == index) return;
  gen_sol_deltas(sol_delta, index + 1);
  sol_delta.flip(index);
  sol_deltas.push_back(sol_delta);
  gen_sol_deltas(sol_delta, index + 1);
}
inline void SearchAlgorithm::search() {
  const int parallel_param = 8;
  SolDelta sol_delta(*this);
  if (hubo_model_.term_count() == 0) {
    register_new_sol(sol_delta);
    return;
  }
  if (var_count() <= 16) {
    register_new_sol(sol_delta);
    sol_delta.search(var_count() - 1);
    return;
  }
  sol_deltas.push_back(sol_delta);
  gen_sol_deltas(sol_delta, var_count() - parallel_param);
  tbb::parallel_for(
      tbb::blocked_range<size_t>(0, sol_deltas.size()),
      [&](const tbb::blocked_range<size_t> &range) {
        for (size_t i = range.begin(); i < range.end(); ++i) {
          register_new_sol(sol_deltas[i]);
          sol_deltas[i].search(var_count() - (parallel_param + 1));
        }
      });
}
inline void SearchAlgorithm::search_optimal_solutions() {
  is_optimal_solutions_ = true;
  search();
  tbb::parallel_sort(all_solutions_.begin(), all_solutions_.end());
}
inline void SearchAlgorithm::search_all_solutions() {
  is_all_solutions_ = true;
  search();
  tbb::parallel_sort(all_solutions_.begin(), all_solutions_.end());
}
}  
}  
